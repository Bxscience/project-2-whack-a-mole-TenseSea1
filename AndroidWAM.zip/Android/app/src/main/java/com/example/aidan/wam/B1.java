package com.example.aidan.wam;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class B1 extends AppCompatActivity {
    int index = 0;
    int[][] indices;
    int[] waits;
    boolean[][] clicked = {{false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}};
    int onClickIndex = -1;

    TextView time;
    TextView score;

    ImageButton b;
    ImageButton b2;
    ImageButton b3;
    ImageButton b4;
    ImageButton b5;
    ImageButton b6;

    ImageButton[] buttons;

    CountDownTimer mole;

    int prevMillisRemaining = 60000;

    boolean activated = false;

    boolean stop = false;
    boolean ok = true;

    CountDownTimer heardPrev0;
    CountDownTimer heardPrev1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b1);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        time = (TextView) findViewById(R.id.time);
        score = (TextView) findViewById(R.id.score);

        /*Intent intent = getIntent();
        int board = intent.getIntExtra("board", 0);

        if(board!=3){

        }*/
        b  = (ImageButton) findViewById(R.id.imageButton);
        b2 = (ImageButton) findViewById(R.id.imageButton2);
        b3 = (ImageButton) findViewById(R.id.imageButton3);
        b4 = (ImageButton) findViewById(R.id.imageButton4);
        b5 = (ImageButton) findViewById(R.id.imageButton5);
        b6 = (ImageButton) findViewById(R.id.imageButton6);

/*
        b7 = (ImageButton) findViewById(R.id.imageButton26);
        b8 = (ImageButton) findViewById(R.id.imageButton30);
        b9 = (ImageButton) findViewById(R.id.imageButton31);
        b10= (ImageButton) findViewById(R.id.imageButton28);
        b11= (ImageButton) findViewById(R.id.imageButton6);
        b12= (ImageButton) findViewById(R.id.imageButton2);
        b13= (ImageButton) findViewById(R.id.imageButton3);
        b14= (ImageButton) findViewById(R.id.imageButton4);
        b15= (ImageButton) findViewById(R.id.imageButton5);
        b16= (ImageButton) findViewById(R.id.imageButton6);

*/

        buttons = new ImageButton[]{b, b2, b3, b4, b5, b6};

        indices = select(6);
        setWaits();
        score.setText("0");
        buttons[indices[0][0]].setVisibility(View.VISIBLE);

        for (int i = 0; i < 6; i++) {
            final int finalI = i;
            buttons[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ok = false;
                    if (buttons[finalI].getVisibility() == View.VISIBLE) {
                        scoreAdd();
                        if (!stop) {
                            final int thisIndex = index;
                            if (finalI == indices[index][0]) {
                                buttons[indices[index][0]].setVisibility(View.INVISIBLE);
                                if (indices[index][1] != -1 && !clicked[index][1]) {
                                    if (onClickIndex != -1) {
                                        buttons[indices[thisIndex][1]].setVisibility(View.INVISIBLE);
                                        clicked[thisIndex][1] = true;
                                        onClickIndex = -1;
                                    } else {
                                        onClickIndex = index;
                                        heardPrev0 = new CountDownTimer(250, 50) {              //waits[index]
                                            @Override
                                            public void onTick(long millisUntilFinished) {
                                                if (clicked[thisIndex][1]) {
                                                    onClickIndex = -1;
                                                }
                                            }

                                            @Override
                                            public void onFinish() {
                                                buttons[indices[thisIndex][1]].setVisibility(View.INVISIBLE);
                                                clicked[thisIndex][1] = true;
                                                onClickIndex = -1;
                                            }
                                        }.start();
                                    }
                                }
                                clicked[index][0] = true;
                            }
                            if (finalI == indices[index][1]) {
                                buttons[indices[index][1]].setVisibility(View.INVISIBLE);
                                if (indices[index][1] != -1 && !clicked[index][0]) {
                                    if (onClickIndex != -1) {
                                        buttons[indices[thisIndex][1]].setVisibility(View.INVISIBLE);
                                        clicked[thisIndex][1] = true;
                                        onClickIndex = -1;
                                    } else {
                                        onClickIndex = index;
                                        heardPrev1 = new CountDownTimer(250, 50) {
                                            @Override
                                            public void onTick(long millisUntilFinished) {
                                                if (clicked[thisIndex][0]) {
                                                    onClickIndex = -1;
                                                }
                                            }

                                            @Override
                                            public void onFinish() {
                                                buttons[indices[thisIndex][0]].setVisibility(View.INVISIBLE);
                                                clicked[thisIndex][0] = true;
                                                onClickIndex = -1;
                                            }
                                        }.start();
                                    }
                                }
                                clicked[index][1] = true;
                            }
                        }
                        ok = true;
                    }
                }
            });
        }
        new CountDownTimer(60000, 100) {
            public void onTick(long millisUntilFinished) {
                time.setText("" + millisUntilFinished / 1000 + "." + (millisUntilFinished % 1000 / 100));
                if (!activated && prevMillisRemaining - millisUntilFinished >= waits[index]) {
                    if (indices[index][1] != -1)
                        buttons[indices[index][1]].setVisibility(View.VISIBLE);
                    activated = true;
                }
                if ((clicked[index][0] && ((indices[index][1] == -1) || clicked[index][1])) || ((prevMillisRemaining - millisUntilFinished) >= 2000)) {
                    stop = true;
                    if (!ok) {
                    } else {
                        buttons[indices[index][0]].setVisibility(View.INVISIBLE);
                        if (indices[index][1] != -1)
                            buttons[indices[index][1]].setVisibility(View.INVISIBLE);
                        activated = false;
                        buttons[indices[++index][0]].setVisibility(View.VISIBLE);
                        stop = false;
                        prevMillisRemaining = (int) millisUntilFinished;
                    }
                }
            }

            public void onFinish() {
            }
        }.start();
    }

    public int[][] select(int n) {
        int[][] arr = new int[200][2];
        arr[0][0] = (int) (Math.random() * n);
        arr[0][1] = -1;
        for (int i = 1; i < 200; i++) {
            arr[i][0] = arr[i - 1][0];
            arr[i][1] = arr[i - 1][0];
            while (arr[i][0] == arr[i - 1][0] || arr[i][0] == arr[i - 1][1]) {
                arr[i][0] = (int) (Math.random() * n);
            }
            while (arr[i][1] == arr[i - 1][0] || arr[i][1] == arr[i][0] || arr[i][1] == arr[i - 1][1] && arr[i][1] != -1) {
                arr[i][1] = Math.random() > i / 250 + 0.01 * n + 0.06 ? -1 : (int) (Math.random() * n);
            }
        }
        return arr;
    }

    public void setWaits() {
        waits = new int[199];
        int n = 7;
        //(int) (Math.pow(Math.random(), 2) * Math.random() * 500);
        for (int i = 0; i < 199; i++)
            waits[i] = (int) (Math.sqrt(((Math.pow(Math.random(), 2) + n) * (Math.pow(Math.random(), 2) + n) - n * n) / (2 * n + 1)) * 10);
    }

    public void scoreAdd() {
        score.setText("" + (Integer.parseInt(score.getText().toString()) + 1));
    }
}













/*
package com.example.aidan.wam;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.Arrays;

public class B1 extends AppCompatActivity {
    int index = 0;
    int[][] indices;
    int[] waits;
    boolean[][] clicked = {{false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false},{false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false},{false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false},{false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false},{false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false},{false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false},{false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false},{false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false},{false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false},{false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false},{false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false},{false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false},{false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false},{false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false},{false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false},{false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false},{false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false},{false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false},{false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false},{false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}};
    int onClickIndex = -1;

    TextView time;
    TextView score;

    ImageButton b;
    ImageButton b2;
    ImageButton b3;
    ImageButton b4;
    ImageButton b5;
    ImageButton b6;

    ImageButton[] buttons;

    CountDownTimer mole;

    int prevMillisRemaining = 60000;

    boolean activated = false;

    boolean stop = false;
    boolean ok = true;

    CountDownTimer heardPrev0;
    CountDownTimer heardPrev1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b1);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        time = (TextView) findViewById(R.id.time);
        score = (TextView) findViewById(R.id.score);

        b = (ImageButton) findViewById(R.id.imageButton);
        b2 = (ImageButton) findViewById(R.id.imageButton2);
        b3 = (ImageButton) findViewById(R.id.imageButton3);
        b4 = (ImageButton) findViewById(R.id.imageButton4);
        b5 = (ImageButton) findViewById(R.id.imageButton5);
        b6 = (ImageButton) findViewById(R.id.imageButton6);

        buttons = new ImageButton[]{b, b2, b3, b4, b5, b6};

        waits = new int[199];
        for (int i = 0; i < 199; i++) {
            waits[i] = (int) (Math.pow(Math.random(), 2) * Math.random() * 500);
        }

        indices = select(6);

        score.setText("0");

        buttons[indices[0][0]].setVisibility(View.VISIBLE);

        for (int i = 0; i < 6; i++) {
            final int finalI = i;
            buttons[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ok = false;
                    if (buttons[finalI].getVisibility() == View.VISIBLE) {
                        scoreAdd();
                        if(!stop) {
                            final int thisIndex = index;
                            if (finalI == indices[index][0]) {
                                buttons[indices[index][0]].setVisibility(View.INVISIBLE);
                                if (indices[index][1] != -1 && !clicked[index][1]) {
                                    if(onClickIndex != -1) {
                                        buttons[indices[thisIndex][1]].setVisibility(View.INVISIBLE);
                                        clicked[thisIndex][1] = true;
                                        onClickIndex = -1;
                                    }
                                    else {
                                        onClickIndex = index;
                                        heardPrev0 = new CountDownTimer(250, 50) {              //waits[index]
                                            @Override
                                            public void onTick(long millisUntilFinished) {
                                                //    if (buttons[indices[index][1]].getVisibility() == View.INVISIBLE) {  //activated upon clicking OR timer restarting
                                                //        millisUntilFinished = 0;                                        // Jump to the end?
                                                //    }
                                                if (clicked[thisIndex][1]) {
                                                    onClickIndex = -1;
                                                }
                                            }

                                            @Override
                                            public void onFinish() {
                                                //if (indices[index][1] != -1)
                                                buttons[indices[thisIndex][1]].setVisibility(View.INVISIBLE);
                                                clicked[thisIndex][1] = true;
                                                //heardPrev1 = null;              //MAYBE
                                                onClickIndex = -1;
                                            }
                                        }.start();
                                    }
                                }
                                clicked[index][0] = true; //may put earlier if the time gap causes errors in first nested if statement in onTick(); or create new global var
                                // wait t[index] ms then try to set the 2nd button to invisible
                            }
                            // Make sure the only ones visible are from the current index; "if(finalI == indices[index][1])" is unnecessary ***********************
                            if (finalI == indices[index][1]) {               //else if?????????????
                                buttons[indices[index][1]].setVisibility(View.INVISIBLE);
                                if (indices[index][1] != -1 && !clicked[index][0]) {                // "indices[index][1] != -1 &&" is unnecessary
                                    if(onClickIndex != -1) {
                                        buttons[indices[thisIndex][1]].setVisibility(View.INVISIBLE);
                                        clicked[thisIndex][1] = true;
                                        onClickIndex = -1;
                                    }
                                    else{
                                        onClickIndex = index;
                                        heardPrev1 = new CountDownTimer(250, 50) {
                                            @Override
                                            public void onTick(long millisUntilFinished) {
                                                //    if (buttons[indices[index][0]].getVisibility() == View.INVISIBLE) {  //activated upon clicking OR timer restarting
                                                //        millisUntilFinished = 0;                                        // Jump to the end
                                                //    }
                                                if (clicked[thisIndex][0]) {
                                                    onClickIndex = -1;
                                                }
                                            }

                                            @Override
                                            public void onFinish() {
                                                buttons[indices[thisIndex][0]].setVisibility(View.INVISIBLE);
                                                clicked[thisIndex][0] = true;
                                                //heardPrev1 = null;              //MAYBE
                                                onClickIndex = -1;
                                            }
                                        }.start();
                                    }
                                }
                                clicked[index][1] = true; //may put earlier if the time gap causes errors in first nested if statement in onTick(); or create new global var
                                // wait t[index] ms then try to set the 1st button to invisible
                            }
                        }
                        */
/*if(stop) {
                            heardPrev0 = null;        //maybe?
                            heardPrev1 = null;        //maybe?
                        }*//*

                        ok = true;
                    }
                }
            });
        }
        new CountDownTimer(60000, 100) {

            //@SuppressLint("SetTextI18n")
            public void onTick(long millisUntilFinished) {
              time.setText("" + millisUntilFinished / 1000 + "." + (millisUntilFinished % 1000 / 100));
                // realTime[0] = (int) millisUntilFinished;
                if(!activated && prevMillisRemaining - millisUntilFinished >= waits[index]) {
                    if(indices[index][1] != -1)
                        buttons[indices[index][1]].setVisibility(View.VISIBLE);
                    activated = true;
                }
                if((clicked[index][0] && ((indices[index][1] == -1) || clicked[index][1])) || ((prevMillisRemaining - millisUntilFinished) >= 2000)) {
                    //timing
                    stop = true;
                    if(!ok) { }
                    else {
                        //ensure blank screen
                        buttons[indices[index][0]].setVisibility(View.INVISIBLE);
                        if (indices[index][1] != -1)
                            buttons[indices[index][1]].setVisibility(View.INVISIBLE);
                        activated = false;
                        //System.wait(...)
                        buttons[indices[++index][0]].setVisibility(View.VISIBLE);
                        stop = false;
                        prevMillisRemaining = (int) millisUntilFinished;
                    }
                }
            }

            public void onFinish() { }
        }.start();
    }

    public int[][] select(int n) {
        int[][] arr = new int[200][2];
        arr[0][0] = (int) (Math.random() * n);
        arr[0][1] = -1;
        for (int i = 1; i < 200; i++) {
            arr[i][0] = arr[i - 1][0];
            arr[i][1] = arr[i - 1][0];
            while (arr[i][0] == arr[i - 1][0] || arr[i][0] == arr[i - 1][1]) {
                arr[i][0] = (int) (Math.random() * n);
            }
            while (arr[i][1] == arr[i - 1][0] || arr[i][1] == arr[i][0] || arr[i][1] == arr[i - 1][1] && arr[i][1] != -1) {
                arr[i][1] = Math.random() > i / 250 + 0.01 * n + 0.06 ? -1 : (int) (Math.random() * n);
            }
        }
        return arr;
    }

    public void scoreAdd() {
        score.setText("" + (Integer.parseInt(score.getText().toString()) + 1));
    }
}*/