package com.example.aidan.wam;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class C extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c);

        Intent intent = getIntent();
        final int board = intent.getIntExtra("n", 6);
        String score = intent.getStringExtra("score");

        final Button b1 = (Button) findViewById(R.id.button4);
        final Button b2 = (Button) findViewById(R.id.button5);

        final TextView scoreReader = findViewById(R.id.textView2);

        scoreReader.setText(score);

        new CountDownTimer(864, 1000) {
            public void onTick(long millisUntilFinished) { }

            public void onFinish(){
                b1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent myIntent = new Intent(C.this, B1.class);
                        myIntent.putExtra("board", board);
                        C.this.startActivity(myIntent);
                    }
                });
                b2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent myIntent = new Intent(C.this, MainActivity.class);
                        myIntent.putExtra("board", board);
                        C.this.startActivity(myIntent);
                    }
                });
            }
        }.start();
    }
}