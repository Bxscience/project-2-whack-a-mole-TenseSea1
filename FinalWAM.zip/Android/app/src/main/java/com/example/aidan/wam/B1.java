package com.example.aidan.wam;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class B1 extends AppCompatActivity {
    int index = 0;
    int[][] indices;
    int[] waits;
    boolean[][] clicked = {{false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}, {false, false}};
    int onClickIndex = -1;

    TextView time;
    TextView score;

    ImageButton[] buttons;

    CountDownTimer mole;

    int prevMillisRemaining = 30000;

    boolean activated = false;

    boolean stop = false;
    boolean ok = true;

    CountDownTimer heardPrev0;
    CountDownTimer heardPrev1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b1);

        time = (TextView) findViewById(R.id.time);
        score = (TextView) findViewById(R.id.score);

        Intent intent = getIntent();
        final int board = intent.getIntExtra("board", 0);

        ImageButton b  = (ImageButton) findViewById(R.id.imageButton);
        ImageButton b2 = (ImageButton) findViewById(R.id.imageButton2);
        ImageButton b3 = (ImageButton) findViewById(R.id.imageButton3);
        ImageButton b4 = (ImageButton) findViewById(R.id.imageButton4);
        ImageButton b5 = (ImageButton) findViewById(R.id.imageButton5);
        ImageButton b6 = (ImageButton) findViewById(R.id.imageButton6);

        ImageButton b7 = (ImageButton) findViewById(R.id.imageButton7);
        ImageButton b8 = (ImageButton) findViewById(R.id.imageButton10);
        ImageButton b9 = (ImageButton) findViewById(R.id.imageButton13);
        ImageButton b10 = (ImageButton) findViewById(R.id.imageButton19);
        ImageButton b11 = (ImageButton) findViewById(R.id.imageButton20);
        ImageButton b12 = (ImageButton) findViewById(R.id.imageButton21);

        ImageButton b13 = (ImageButton) findViewById(R.id.imageButton9);
        ImageButton b14 = (ImageButton) findViewById(R.id.imageButton11);
        ImageButton b15 = (ImageButton) findViewById(R.id.imageButton12);
        ImageButton b16 = (ImageButton) findViewById(R.id.imageButton18);
        ImageButton b17 = (ImageButton) findViewById(R.id.imageButton16);
        ImageButton b18 = (ImageButton) findViewById(R.id.imageButton17);
        ImageButton b19 = (ImageButton) findViewById(R.id.imageButton15);
        ImageButton b20 = (ImageButton) findViewById(R.id.imageButton14);

        buttons = new ImageButton[]{b, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18, b19, b20};
        for (int i = board; i < 20; i++) buttons[i].setVisibility(View.GONE);

        indices = select(board);
        setWaits();
        score.setText("0");
        buttons[indices[0][0]].setVisibility(View.VISIBLE);

        for (int i = 0; i < board; i++) {
            final int finalI = i;
            buttons[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ok = false;
                    if (buttons[finalI].getVisibility() == View.VISIBLE) {
                        scoreAdd();
                        if (!stop) {
                            final int thisIndex = index;
                            if (finalI == indices[index][0]) {
                                buttons[indices[index][0]].setVisibility(View.INVISIBLE);
                                if (indices[index][1] != -1 && !clicked[index][1]) {
                                    if (onClickIndex != -1) {
                                        buttons[indices[thisIndex][1]].setVisibility(View.INVISIBLE);
                                        clicked[thisIndex][1] = true;
                                        onClickIndex = -1;
                                    } else {
                                        onClickIndex = index;
                                        heardPrev0 = new CountDownTimer(250, 1) {              //waits[index]
                                            @Override
                                            public void onTick(long millisUntilFinished) {
                                                if (clicked[thisIndex][1]) {
                                                    onClickIndex = -1;
                                                }
                                            }

                                            @Override
                                            public void onFinish() {
                                                buttons[indices[thisIndex][1]].setVisibility(View.INVISIBLE);
                                                clicked[thisIndex][1] = true;
                                                onClickIndex = -1;
                                            }
                                        }.start();
                                    }
                                }
                                clicked[index][0] = true;
                            }
                            if (finalI == indices[index][1]) {
                                buttons[indices[index][1]].setVisibility(View.INVISIBLE);
                                if (indices[index][1] != -1 && !clicked[index][0]) {
                                    if (onClickIndex != -1) {
                                        buttons[indices[thisIndex][1]].setVisibility(View.INVISIBLE);
                                        clicked[thisIndex][1] = true;
                                        onClickIndex = -1;
                                    } else {
                                        onClickIndex = index;
                                        heardPrev1 = new CountDownTimer(250, 1) {
                                            @Override
                                            public void onTick(long millisUntilFinished) {
                                                if (clicked[thisIndex][0]) {
                                                    onClickIndex = -1;
                                                }
                                            }

                                            @Override
                                            public void onFinish() {
                                                buttons[indices[thisIndex][0]].setVisibility(View.INVISIBLE);
                                                clicked[thisIndex][0] = true;
                                                onClickIndex = -1;
                                            }
                                        }.start();
                                    }
                                }
                                clicked[index][1] = true;
                            }
                        }
                        ok = true;
                    }
                }
            });
        }
        new CountDownTimer(30000, 1) {
            public void onTick(long millisUntilFinished) {
                time.setText("" + millisUntilFinished / 1000 + "." + (millisUntilFinished % 1000 / 100));
                if (!activated && prevMillisRemaining - millisUntilFinished >= waits[index]) {
                    if (indices[index][1] != -1)
                        buttons[indices[index][1]].setVisibility(View.VISIBLE);
                    activated = true;
                }
                if ((clicked[index][0] && ((indices[index][1] == -1) || clicked[index][1])) || ((prevMillisRemaining - millisUntilFinished) >= 2000)) {
                    stop = true;
                    if (ok) {
                        buttons[indices[index][0]].setVisibility(View.INVISIBLE);
                        if (indices[index][1] != -1)
                            buttons[indices[index][1]].setVisibility(View.INVISIBLE);
                        activated = false;
                        buttons[indices[++index][0]].setVisibility(View.VISIBLE);
                        stop = false;
                        prevMillisRemaining = (int) millisUntilFinished;
                    }
                }
            }

            public void onFinish() {
                Intent intent2 = new Intent(B1.this, C.class);
                intent2.putExtra("score", score.getText());
                intent2.putExtra("n", board);
                B1.this.startActivity(intent2);
            }
        }.start();
    }

    public int[][] select(int n) {
        int[][] arr = new int[200][2];
        arr[0][0] = (int) (Math.random() * n);
        arr[0][1] = -1;
        for (int i = 1; i < 200; i++) {
            arr[i][0] = arr[i - 1][0];
            arr[i][1] = arr[i - 1][0];
            while (arr[i][0] == arr[i - 1][0] || arr[i][0] == arr[i - 1][1]) {
                arr[i][0] = (int) (Math.random() * n);
            }
            while (arr[i][1] == arr[i - 1][0] || arr[i][1] == arr[i][0] || arr[i][1] == arr[i - 1][1] && arr[i][1] != -1) {
                arr[i][1] = (Math.random() > ((i / 250) + (0.01 * n) + 0.06)) ? -1 : (int) (Math.random() * n);
            }
        }
        return arr;
    }

    public void setWaits() {
        waits = new int[199];
        int n = 7;
        for (int i = 0; i < 199; i++)
            waits[i] = (int) (Math.sqrt(((Math.pow(Math.random(), 2) + n) * (Math.pow(Math.random(), 2) + n) - n * n) / (2 * n + 1)) * 10);
    }

    public void scoreAdd() {
        score.setText("" + (Integer.parseInt(score.getText().toString()) + 1));
    }
}